package com.danzz208.proxy;

import android.app.Activity;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(10, 5, 22);
    private static final int PANEL = Color.rgb(30, 17, 53);
    private static final int PURPLE = Color.rgb(151, 71, 255);
    private static final int LAVENDER = Color.rgb(214, 174, 255);
    private static final int MUTED = Color.rgb(177, 157, 205);
    private boolean connected = false;
    private TextView status;
    private Button connectButton;

    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke);
        return d;
    }
    private TextView label(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private LinearLayout.LayoutParams lp(int w,int h) { return new LinearLayout.LayoutParams(w,h); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        showLogin();
    }

    private void showLogin() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(18),dp(22),dp(18)); root.setBackground(new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,new int[]{Color.rgb(38,15,67),BG,Color.rgb(7,4,15)}));
        TextView brand = label("DANZZ 208 PROXYY",20,Color.WHITE,true);
        brand.setGravity(Gravity.CENTER); root.addView(brand,lp(-1,dp(42)));
        TextView sub = label("SECURE NETWORK EXPERIENCE",10,LAVENDER,true);
        sub.setGravity(Gravity.CENTER); root.addView(sub,lp(-1,dp(22)));

        FrameLayout videoFrame = new FrameLayout(this);
        videoFrame.setBackground(shape(PANEL,24,PURPLE));
        VideoView video = new VideoView(this);
        FrameLayout.LayoutParams vp = new FrameLayout.LayoutParams(-1,-1);
        videoFrame.addView(video,vp);
        TextView overlay = label("WELCOME BACK",18,Color.WHITE,true);
        overlay.setGravity(Gravity.CENTER);
        overlay.setShadowLayer(12,0,0,PURPLE);
        FrameLayout.LayoutParams op = new FrameLayout.LayoutParams(-1,dp(48),Gravity.BOTTOM);
        op.bottomMargin=dp(10); videoFrame.addView(overlay,op);
        LinearLayout.LayoutParams vfp=lp(-1,dp(220)); vfp.topMargin=dp(14);
        root.addView(videoFrame,vfp);
        Uri uri=Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.login_video);
        video.setVideoURI(uri);
        video.setOnPreparedListener(mp->{ mp.setLooping(true); mp.setVolume(0f,0f); video.start(); });

        LinearLayout form = new LinearLayout(this); form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(18),dp(20),dp(18),dp(20)); form.setBackground(shape(PANEL,22,Color.rgb(112,55,174)));
        TextView title=label("SIGN IN",18,Color.WHITE,true); form.addView(title);
        EditText user=field("Username",InputType.TYPE_CLASS_TEXT);
        EditText pass=field("Password",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        LinearLayout.LayoutParams fp=lp(-1,dp(52)); fp.topMargin=dp(14); form.addView(user,fp);
        LinearLayout.LayoutParams pp=lp(-1,dp(52)); pp.topMargin=dp(10); form.addView(pass,pp);
        Button login=new Button(this); login.setText("LOGIN  ✦"); login.setTextColor(Color.WHITE);
        login.setAllCaps(false); login.setTextSize(15); login.setBackground(shape(PURPLE,16,LAVENDER));
        LinearLayout.LayoutParams bp=lp(-1,dp(52)); bp.topMargin=dp(16); form.addView(login,bp);
        login.setOnClickListener(v->{ if(user.getText().length()==0 || pass.getText().length()==0)
            Toast.makeText(this,"Masukkan username dan password",Toast.LENGTH_SHORT).show();
            else { video.stopPlayback(); showDashboard(user.getText().toString()); }});
        LinearLayout.LayoutParams formP=lp(-1,-2); formP.topMargin=dp(16); root.addView(form,formP);
        TextView foot=label("DANZZ 208 PROXYY  •  VIOLET EDITION",9,MUTED,true);
        foot.setGravity(Gravity.CENTER); LinearLayout.LayoutParams f=lp(-1,-2); f.topMargin=dp(16); root.addView(foot,f);
        setContentView(root);
    }
    private EditText field(String hint,int type) {
        EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setTextColor(Color.WHITE);
        e.setHintTextColor(MUTED); e.setInputType(type); e.setPadding(dp(14),0,dp(14),0);
        e.setBackground(shape(Color.rgb(18,10,32),14,Color.rgb(103,61,148))); return e;
    }

    private void showDashboard(String username) {
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(24),dp(22),dp(18));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{Color.rgb(38,15,67),BG,Color.rgb(7,4,15)}));
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView avatar=new ImageView(this);
        Bitmap bm=BitmapFactory.decodeResource(getResources(),R.drawable.moon_profile);
        Bitmap circle=Bitmap.createBitmap(bm.getWidth(),bm.getHeight(),Bitmap.Config.ARGB_8888);
        Canvas c=new Canvas(circle); Paint p=new Paint(3); p.setShader(new BitmapShader(bm,Shader.TileMode.CLAMP,Shader.TileMode.CLAMP));
        float scale=Math.max((float)dp(54)/bm.getWidth(),(float)dp(54)/bm.getHeight());
        Matrix m=new Matrix(); m.setScale(scale,scale); m.postTranslate((dp(54)-bm.getWidth()*scale)/2,(dp(54)-bm.getHeight()*scale)/2); p.getShader().setLocalMatrix(m);
        c.drawCircle(dp(27),dp(27),dp(27),p); avatar.setImageBitmap(circle);
        avatar.setBackground(shape(BG,40,LAVENDER)); avatar.setClipToOutline(true);
        header.addView(avatar,lp(dp(54),dp(54)));
        LinearLayout brand=new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        brand.addView(label("DANZZ 208 PROXYY",18,Color.WHITE,true));
        brand.addView(label("VIOLET NETWORK",9,LAVENDER,true));
        LinearLayout.LayoutParams br= new LinearLayout.LayoutParams(0,-2,1); br.leftMargin=dp(12); header.addView(brand,br);
        header.addView(label("⚙",24,MUTED,false)); root.addView(header);

        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18),dp(18),dp(18),dp(18)); card.setBackground(shape(PANEL,24,Color.rgb(126,69,190)));
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(label("◉  CONNECTION",12,MUTED,true),new LinearLayout.LayoutParams(0,-2,1));
        status=label("● DISCONNECTED",10,MUTED,true); top.addView(status); card.addView(top);
        LinearLayout holder=new LinearLayout(this); holder.setGravity(Gravity.CENTER); holder.setPadding(0,dp(26),0,dp(20));
        connectButton=new Button(this); connectButton.setText("✦\nCONNECT"); connectButton.setTextSize(15);
        connectButton.setTextColor(Color.WHITE); connectButton.setAllCaps(false); connectButton.setBackground(shape(PURPLE,100,LAVENDER));
        connectButton.setOnClickListener(v->{connected=!connected; updateConnection();});
        holder.addView(connectButton,lp(dp(145),dp(145))); card.addView(holder);
        card.addView(label("Ready to establish secure tunnel",12,MUTED,false));
        LinearLayout.LayoutParams cp=lp(-1,-2); cp.topMargin=dp(28); root.addView(card,cp);
        LinearLayout row=new LinearLayout(this);
        row.addView(infoCard("SESSION","--:--:--"),new LinearLayout.LayoutParams(0,-2,1));
        View gap=new View(this); row.addView(gap,lp(dp(10),1));
        row.addView(infoCard("PROTOCOL","SOCKS5"),new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams rp=lp(-1,-2); rp.topMargin=dp(16); root.addView(row,rp);
        LinearLayout hunt=new LinearLayout(this); hunt.setOrientation(LinearLayout.VERTICAL);
        hunt.setPadding(dp(16),dp(16),dp(16),dp(16)); hunt.setBackground(shape(PANEL,20,Color.TRANSPARENT));
        hunt.addView(label("SERVER HUNT",13,Color.WHITE,true));
        LinearLayout modes=new LinearLayout(this); modes.setGravity(Gravity.CENTER_VERTICAL);
        for(String n:new String[]{"SMART HUNT","ASN EXACT","ISP MATCH","SUBNET"}) {
            TextView chip=label(n,10,Color.WHITE,true); chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(10),dp(9),dp(10),dp(9)); chip.setBackground(shape(Color.rgb(55,27,83),20,PURPLE));
            LinearLayout.LayoutParams x=lp(-2,-2); x.topMargin=dp(12); x.rightMargin=dp(6); modes.addView(chip,x);
        }
        hunt.addView(modes); LinearLayout.LayoutParams hp=lp(-1,-2); hp.topMargin=dp(16); root.addView(hunt,hp);
        TextView foot=label("DANZZ 208 PROXYY  •  BUILD 1.1.0",9,MUTED,true); foot.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ft=lp(-1,-2); ft.topMargin=dp(22); root.addView(foot,ft);
        setContentView(root);
    }
    private LinearLayout infoCard(String title,String value) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14),dp(14),dp(14),dp(14)); box.setBackground(shape(PANEL,18,Color.TRANSPARENT));
        box.addView(label(title,9,MUTED,true)); TextView v=label(value,17,LAVENDER,true);
        LinearLayout.LayoutParams p=lp(-1,-2); p.topMargin=dp(7); box.addView(v,p); return box;
    }
    private void updateConnection() {
        status.setText(connected?"● CONNECTED":"● DISCONNECTED");
        status.setTextColor(connected?Color.rgb(113,240,180):MUTED);
        connectButton.setText(connected?"DISCONNECT":"✦\nCONNECT");
        connectButton.setBackground(shape(connected?Color.rgb(45,83,70):PURPLE,100,LAVENDER));
    }
}
