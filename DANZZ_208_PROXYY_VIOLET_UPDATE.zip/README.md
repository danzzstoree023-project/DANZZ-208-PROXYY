# DANZZ 208 PROXYY — Violet Edition

Android starter project for building a debug APK with GitHub Actions.

## Build
1. Upload the contents of this project to the repository root (including `.github/workflows/build-apk.yml`).
2. Keep the project ZIP in the repository root if using the ZIP-extraction workflow.
3. Open GitHub Actions and run **Build DANZZ 208 PROXYY APK**.
4. Download the `DANZZ-208-PROXYY-APK` artifact.

## Included in this update
- Violet-themed login screen with the supplied looping, muted video.
- Username/password fields (local demo gate only; not connected to a real account backend).
- Supplied moon/star image as the circular dashboard profile image.
- Violet dashboard and connection demo UI.

## Important
The CONNECT button is still a visual demo. This build does not yet establish a real VPN/SOCKS5 tunnel, authenticate against a backend, or meter proxy traffic. Do not use real credentials in this demo login.
