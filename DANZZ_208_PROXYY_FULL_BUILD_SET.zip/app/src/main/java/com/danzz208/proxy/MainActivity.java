package com.danzz208.proxy;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(5, 11, 27);
    private static final int PANEL = Color.rgb(13, 25, 51);
    private static final int BLUE = Color.rgb(22, 139, 255);
    private static final int CYAN = Color.rgb(69, 217, 255);
    private static final int MUTED = Color.rgb(145, 168, 201);

    private boolean connected = false;
    private TextView status;
    private Button connectButton;

    private GradientDrawable shape(int color, int radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        float density = getResources().getDisplayMetrics().density;
        d.setCornerRadius(radiusDp * density);
        if (strokeColor != Color.TRANSPARENT) d.setStroke((int)(1.5f * density), strokeColor);
        return d;
    }

    private TextView label(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int width, int height) {
        return new LinearLayout.LayoutParams(width, height);
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7, 18, 39));
        getWindow().setNavigationBarColor(NAVY);
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(18));
        GradientDrawable background = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{Color.rgb(11, 29, 60), NAVY, Color.rgb(3, 7, 18)}
        );
        root.setBackground(background);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView logo = label("⚡", 25, Color.WHITE, true);
        logo.setGravity(Gravity.CENTER);
        logo.setBackground(shape(BLUE, 14, CYAN));
        header.addView(logo, lp(dp(50), dp(50)));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.addView(label("DANZZ 208 PROXYY", 19, Color.WHITE, true));
        brand.addView(label("PREMIUM MOBILE NETWORK", 9, CYAN, true));
        LinearLayout.LayoutParams brandParams = new LinearLayout.LayoutParams(0, -2, 1);
        brandParams.leftMargin = dp(12);
        header.addView(brand, brandParams);
        header.addView(label("⚙", 24, MUTED, false));
        root.addView(header);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(shape(PANEL, 24, Color.rgb(32, 105, 190)));

        LinearLayout cardTop = new LinearLayout(this);
        cardTop.setGravity(Gravity.CENTER_VERTICAL);
        TextView connection = label("◉  CONNECTION", 12, MUTED, true);
        cardTop.addView(connection, new LinearLayout.LayoutParams(0, -2, 1));
        status = label("● DISCONNECTED", 10, MUTED, true);
        cardTop.addView(status);
        card.addView(cardTop);

        LinearLayout buttonHolder = new LinearLayout(this);
        buttonHolder.setGravity(Gravity.CENTER);
        buttonHolder.setPadding(0, dp(26), 0, dp(20));
        connectButton = new Button(this);
        connectButton.setText("⚡\nCONNECT");
        connectButton.setTextSize(15);
        connectButton.setTextColor(Color.WHITE);
        connectButton.setAllCaps(false);
        connectButton.setBackground(shape(BLUE, 100, CYAN));
        connectButton.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                connected = !connected;
                updateConnection();
            }
        });
        buttonHolder.addView(connectButton, lp(dp(145), dp(145)));
        card.addView(buttonHolder);
        card.addView(label("Ready to establish secure tunnel", 12, MUTED, false));

        LinearLayout.LayoutParams cardParams = lp(-1, -2);
        cardParams.topMargin = dp(28);
        root.addView(card, cardParams);

        LinearLayout infoRow = new LinearLayout(this);
        infoRow.addView(infoCard("SESSION", "--:--:--"), new LinearLayout.LayoutParams(0, -2, 1));
        View gap = new View(this);
        infoRow.addView(gap, lp(dp(10), 1));
        infoRow.addView(infoCard("PROTOCOL", "SOCKS5"), new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams infoParams = lp(-1, -2);
        infoParams.topMargin = dp(16);
        root.addView(infoRow, infoParams);

        LinearLayout hunt = new LinearLayout(this);
        hunt.setOrientation(LinearLayout.VERTICAL);
        hunt.setPadding(dp(16), dp(16), dp(16), dp(16));
        hunt.setBackground(shape(PANEL, 20, Color.TRANSPARENT));
        hunt.addView(label("SERVER HUNT", 13, Color.WHITE, true));

        LinearLayout modes = new LinearLayout(this);
        modes.setGravity(Gravity.CENTER_VERTICAL);
        String[] names = {"SMART", "ASN", "ISP"};
        for (String name : names) {
            TextView chip = label(name, 11, Color.WHITE, true);
            chip.setGravity(Gravity.CENTER);
            chip.setPadding(dp(16), dp(9), dp(16), dp(9));
            chip.setBackground(shape(Color.rgb(20, 58, 103), 24, BLUE));
            LinearLayout.LayoutParams chipParams = lp(-2, -2);
            chipParams.topMargin = dp(12);
            chipParams.rightMargin = dp(8);
            modes.addView(chip, chipParams);
        }
        hunt.addView(modes);
        LinearLayout.LayoutParams huntParams = lp(-1, -2);
        huntParams.topMargin = dp(16);
        root.addView(hunt, huntParams);

        TextView footer = label("DANZZ 208 PROXYY  •  BUILD 1.0.0", 9, MUTED, true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerParams = lp(-1, -2);
        footerParams.topMargin = dp(22);
        root.addView(footer, footerParams);

        setContentView(root);
    }

    private LinearLayout infoCard(String title, String value) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.setBackground(shape(PANEL, 18, Color.TRANSPARENT));
        box.addView(label(title, 9, MUTED, true));
        TextView v = label(value, 17, CYAN, true);
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.topMargin = dp(7);
        box.addView(v, p);
        return box;
    }

    private void updateConnection() {
        status.setText(connected ? "● CONNECTED" : "● DISCONNECTED");
        status.setTextColor(connected ? Color.rgb(101, 240, 178) : MUTED);
        connectButton.setText(connected ? "DISCONNECT" : "⚡\nCONNECT");
        connectButton.setBackground(shape(
            connected ? Color.rgb(18, 60, 85) : BLUE, 100, CYAN
        ));
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }
}
